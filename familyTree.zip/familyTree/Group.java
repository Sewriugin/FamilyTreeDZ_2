package OOP.familyTree;

import java.util.List;

public interface Group extends Iterable<Human> {
    void addHuman(Human human);
    List<Human> getHumanList();
}
