package OOP.familyTree;

import java.util.Iterator;

public class Main {
    public static void main(String[] args) {
        Group group = new FamilyTree();
        Service service = new Service((FamilyTree) group);
        service.addHuman("Павел Геннадьевич Иванов", Gender.Male, 34);
        service.addHuman("Мария Петровна Петрова", Gender.Female, 25);
        service.addHuman("Александр Петрович Кузнецов", Gender.Male, 45);
        service.addHuman("Наталья Ивановна Кудряшова", Gender.Female, 5);


        Iterator<Human> iterator = group.iterator();
        while (iterator.hasNext()){
            Human human = iterator.next();
            System.out.println(human);
        }
//        for (Human human: group){
//            System.out.println(human);
//        }

        service.sortByName();
        System.out.println();


        for (Human human: group){
            System.out.println(human);
        }

        service.sortById();
        System.out.println();

        for (Human human: group){
            System.out.println(human);
        }

    }
}
