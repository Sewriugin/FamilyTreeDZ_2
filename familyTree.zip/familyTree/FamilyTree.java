package OOP.familyTree;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FamilyTree implements Group {
    private List<Human> humanList;

    public FamilyTree() {
        humanList = new ArrayList<>();
    }

    public void addHuman(Human human){
        humanList.add(human);
    }

    @Override
    public List<Human> getHumanList() {
        return humanList;
    }


    @Override
    public Iterator<Human> iterator() {
        return new HumanIterator(humanList);
    }
}