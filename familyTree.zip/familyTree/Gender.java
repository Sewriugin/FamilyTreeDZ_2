package OOP.familyTree;

public enum Gender {
    Male, Female;   // Мужчина, Женщина
}

