package OOP.familyTree;

import java.util.List;

public interface AddHuman extends Iterable<Human> {
    void addHuman(Human human);
    List<Human> getHumanList();
}
